
package exerc11_janelas;

public class Exerc11_Janelas {

    public static void main(String[] args) {
        // TODO 01 - crie aqui um objeto da classe JanelaLogin de nome janelaLogin
        
        // TODO 02 - através do objeto janelaLogin, acesse o método setSize 
        ////////// e passe os seguintes valores: 300, 300
        // TODO 03 - através do objeto janelaLogin, acesse o método setDefaultCloseOperation 
        ////////// e passe o seguinte valor: JFrame.EXIT_ON_CLOSE (realize importação)
        // TODO 04 - através do objeto janelaLogin, acesse o método setVisible 
        ////////// e passe o seguinte valor: true
        
        // TODO 05 - execute o projeto, digite valores nos campos e clique no botão!
        ////////// o que acontece?
        
    }
    
}
