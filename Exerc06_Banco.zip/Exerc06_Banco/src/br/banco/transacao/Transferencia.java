package br.banco.transacao;

// TODO 03 - herde a classe Transacao

public class Transferencia {

    private String contaOrigem;
    private String contaDestino;

    public String getContaOrigem() {
        return contaOrigem;
    }

    public void setContaOrigem(String contaOrigem) {
        this.contaOrigem = contaOrigem;
    }

    public String getContaDestino() {
        return contaDestino;
    }

    public void setContaDestino(String contaDestino) {
        this.contaDestino = contaDestino;
    }
    
    // TODO 04 - crie o método emitirComprovante (público, não recebe e nem retorna nada)
    //////////// este método deve imprimir os atributos desta classe, através do get
    
    
}
