
package exerc06_banco;

public class Exerc06_Banco {

    public static void main(String[] args) {
        // TODO 05 - crie um objeto da classe PagamentoBoleto chamado boleto1
        // TODO 06 - através do objeto boleto1, acesse o método set dos atributos da classe e 
        //////////// atribua valores em todos eles, inclusive naqueles atributos que são herdados
        
        // TODO 07 - crie um objeto da classe Transferencia chamado transf1
        // TODO 08 - através do objeto transf1, acesse o método set dos atributos da classe e 
        //////////// atribua valores em todos eles, inclusive naqueles atributos que são herdados
        
        // TODO 09 - chame a método emitirComprovante através do objeto boleto1
        // TODO 10 - chame a método emitirComprovante através do objeto transf1
        
        // TODO 11 - execute o projeto!
        
        // TODO 12 - comente: os atributos da superclasse (Transferencia) são impressos? Justifique.
        //////////// R:
        
        // TODO 13 - comente: o que pode ser feito para resolver este problema?
        //////////// R:
        
        // TODO 14 - preste atenção para solucionar o problema! Depois, faça.
        
    }
    
}
