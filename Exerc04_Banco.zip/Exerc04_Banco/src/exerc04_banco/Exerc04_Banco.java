
package exerc04_banco;

/*
    TODO 01 - LEIA O OBJETIVO DO PROJETO:
    O objetivo deste projeto é criar um programa para exemplificar os conceitos de herança em POO;
    O cenário escolhido foi um banco;
    A princípio, dois tipos de transações bancárias poderão ser realizadas: transferência e boleto bancário.
*/

public class Exerc04_Banco {

    // TODO 02 - crie um pacote de nome br.banco.transacao
    // TODO 03 - dentro de br.banco.transacao, crie uma classe chamada Transferencia
    
    //////////// FAZER DENTRO DA CLASSE Transferencia:
    // TODO 04 - crie os atributos descricao, valor, data, contaOrigem, contaDestino
    //////////// os atributos acima são String, exceto o 'valor' e devem ser declarados como privados
    // TODO 05 - crie os métodos de configuração set e get dos atributos    
    // TODO 06 - programe um método público de nome emitirComprovante
    //////////// este método não retorna nada e não recebe nenhum parâmetro
    // TODO 07 - dentro do método emitirComprovante, imprima todos os valores dos atributos
    //////////// use os métodos get para pegar os valores
    // TODO 08 - a classe Transferencia está representando os dados de boleto bancário também?
    //////////// R:
    // TODO 09 - adicione os seguintes atributos na classe Transferencia:
    //////////// linhaDigitavel, dataVencimento e cedente (todos String)
    // TODO 10 - altere o método emitirComprovante para imprimir os novos atributos
    //////////// faça um if-else para verificar se a conta de origem foi informada ou não
    //////////// se ela for diferente de null, imprima as informações de transferência bancária
    //////////// senão, imprima as informações de boletos bancários
    // TODO 11 - modifique o nome da classe para Transacao 
    //////////// (clique com o botão direito em cima da classe: Refatorar -> Renomear...)
    // TODO 12 - o que acha desta classe? ela está adequada ao cenário banco? Justifique.
    //////////// R:    
    
    public static void main(String[] args) {
        
        
        
    }
    
}
