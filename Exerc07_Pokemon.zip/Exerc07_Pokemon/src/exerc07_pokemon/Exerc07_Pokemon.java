
package exerc07_pokemon;

    // TODO 1: O objetivo deste projeto é aplicar os conceitos de POO 
    // com base nas aventuras do Pokemón

public class Exerc07_Pokemon {

    public static void main(String[] args) {
        // TODO 2: Crie o pacote br.pokemon.personagem
        // TODO 3: Dentro do pacote br.pokemon.personagem, crie a classe Pokemon
        
        // FAÇA DENTRO DA CLASSE POKEMON:
            // TODO 4: declare e encapsule os atributos nome e força
            // TODO 5: crie o construtor parametrizado, considerando os dois atributos da classe,
            // sendo que os atributos são modificados pelos métodos set respectivos.
            // TODO 6: programe o método comer. Esse método é protegido, não retorna nada, mas recebe 
            // como entrada o nome do alimento que o pokemon irá comer. O método deve imprimir o 
            // nome do pokemón e o que ele está comendo. Ex: Pikachu está comendo cereal.
            
        // TODO 7: Dentro do pacote br.pokemon.personagem, crie a classe Squirtle
        // FAÇA DENTRO DA CLASSE SQUIRTLE:
            // TODO 8: Responda: Esta classe pode relacionar-se com a classe Pokemon?
            // R:
            // TODO 9: realize o relacionamento de herança com a classe Pokemon. Isso vai gerar um erro
            // mas continue o projeto mesmo assim.
            // TODO 10: declare e encapsule o atributo fatorMultiplicadorAgua
            // TODO 11: crie o construtor parametrizado, considerando os dois atributos da 
            // superclase apenas.
            // TODO 12: programe o método usarWaterCannon. Ele deve ser público, receber um valor
            // entre 1 e 100 e deve retornar o valor do dano causado. O cálculo do dano
            // é o fatorMultiplicadorAgua multiplicado pela raiz quadrada do valor de entrada
            // e pela força do pokemon.
            
        // TODO 13: Dentro do pacote br.pokemon.personagem, crie a classe Charmander
        // FAÇA DENTRO DA CLASSE CHARMANDER:
            // TODO 14: Responda: Esta classe pode relacionar-se com a classe Pokemon?
            // R:
            // TODO 15: realize o relacionamento de herança com a classe Pokemon. Isso vai gerar um erro
            // mas continue o projeto mesmo assim.
            // TODO 16: declare e encapsule o atributo fatorMultiplicadorFogo
            // TODO 17: crie o construtor parametrizado, considerando os dois atributos da 
            // superclase apenas.
            // TODO 18: programe o método usarFireBall. Ele deve ser público receber um valor
            // entre 1 e 100 e deve retornar o valor do dano causado. O cálculo do dano
            // é o fatorMultiplicadorFogo multiplicado pela raiz cúbica do valor de entrada do método
            // e pela força do pokemon.
        
        // TODO 19: VÁ PARA O Exerc08!
    }
    
}
