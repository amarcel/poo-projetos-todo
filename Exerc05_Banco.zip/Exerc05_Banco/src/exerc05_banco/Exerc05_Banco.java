
package exerc05_banco;

public class Exerc05_Banco {

    public static void main(String[] args) {
        
        
        
    }
    
}
