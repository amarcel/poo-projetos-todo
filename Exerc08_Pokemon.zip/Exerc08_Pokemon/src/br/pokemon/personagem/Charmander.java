
package br.pokemon.personagem;

public class Charmander extends Pokemon {
    private double fatorMultiplicadorFogo;
    
    public Charmander(String nome, int forca) {
        super(nome, forca);
    }
    
    public double usarFireBall(double intensidade) {
        return this.fatorMultiplicadorFogo * Math.cbrt(intensidade) * this.getForca();
    }

}
