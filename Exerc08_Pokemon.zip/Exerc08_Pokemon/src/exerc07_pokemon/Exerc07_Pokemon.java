
package exerc07_pokemon;

public class Exerc07_Pokemon {

    public static void main(String[] args) {
        // TODO 1: Tente instanciar um objeto da classe Squirtle de nome s1 usando o 
        // construtor não parametrizado
        
        // TODO 2: Há erro? Por quê?
        // R:
        
        // TODO 3: Agora, instancie o objeto s1 usando o construtor parametrizado
        
        // TODO 4: Através de s1, altere o nome, a força e o fator multiplicador de água 
        // desse Squirtle
        
        
        // TODO 5: Instacie o objeto da classe Charmander de nome c1.
        
        // TODO 6: Através de c1, altere o nome, a força e o fator multiplicador de fogo
        
        
        // TODO 7: Gere dois números reais aleatórios entre 1 e 100
        // (use a classe Random do Java para essa tarefa)
        
        // TODO 8: Passe o primeiro número aleatório para o método de ataque do Squirtle
        // e armazene o valor em uma variável
        
        // TODO 9: Passe o segundo número aleatório para o método de ataque do Charmander
        // e armazene o valor em uma variável
        
        
        // TODO 10: Implemente aqui a regra que imprime o vencedor
        
    }
    
}
